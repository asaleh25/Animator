package ViewTest;


import cs3500.animator.model.*;
import cs3500.animator.view.IView;
import cs3500.animator.view.TextualView;
import org.junit.Assert;
import org.junit.Test;

public class TextualViewTest {

    IView<String, AShape, AAnimation> view1;
    EasyAnimatorOperations model1;
    EasyAnimatorOperations model2;
    AShape shape1;
    AShape shape2;
    AShape shape3;
    AAnimation move1;
    AAnimation move2;
    AAnimation move3;
    AAnimation move4;
    AAnimation changeColor1;
    AAnimation changeColor2;
    AAnimation changeColor3;
    AAnimation scale1;
    AAnimation scale2;
    AAnimation scale3;
    MyColor color1;
    MyColor color2;
    MyColor color3;
    Posn xy1;
    Posn xy2;
    Posn xy3;
    AAnimation scale4;

    /**
     * Initial Conditions for tests.
     */
    void initConditions() {

        model1 = new EasyAnimatorModel();
        model2 = new EasyAnimatorModel();
        model1.startAnimator();
        color1 = new MyColor(0,0,0);
        color2 = new MyColor(100, 100, 100);
        color3 = new MyColor(100,100,100);
        xy1 = new Posn(1, 10);
        xy2 = new Posn(10, 10);
        xy3 = new Posn(10, 10);
        shape1 = new Rectangle("A", color2, 0, 100, 10, 20, xy1);
        shape2 = new Oval("B", color1, 0, 100, xy2, 50, 50);
        shape3 = new Oval("C", color1, 500, 600, xy2, 50, 50);
        move1 = new Move(shape1, 50, 100, xy2);
        move2 = new Move(shape2, 50, 100, xy1);
        move3 = new Move(shape2, 50, 100, xy1);
        move4 = new Move(shape2, 75, 150, xy1);
        changeColor1 = new ColorChange(shape1, 50, 100, color1);
        changeColor2 = new ColorChange(shape1, 50, 100, color1);
        changeColor3 = new ColorChange(shape2, 0, 50, color2);
        scale1 = new Scale(shape2, 0, 50, 50, 100);
        scale2 = new Scale(shape2, 0,50, 50, 100);
        scale3 = new Scale(shape1, 50, 100, 2, 3);
        view1 = new TextualView(2);

    }

    @Test
    public void testTextualView() {

        this.initConditions();
        model1.addShape(shape1);
        model1.addShape(shape2);
        model1.addAnimation(scale1);
        model1.addAnimation(move1);
        model1.addAnimation(move2);
        String textView = view1.render(model1);
        Assert.assertEquals(true, textView.contains("Min-Corner"));
        Assert.assertEquals(false, textView.contains("Lower"));
        Assert.assertEquals(true, textView.contains("50"));


    }

    @Test
    public void testConvertTicks() {

        this.initConditions();
        Assert.assertEquals(view1.convertTicks(2), 1, 0);
        Assert.assertEquals(view1.convertTicks(0),0, 0);
    }

}