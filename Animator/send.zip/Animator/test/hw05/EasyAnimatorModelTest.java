package hw05;

import cs3500.animator.model.*;
import cs3500.animator.view.IView;
import cs3500.animator.view.VisualView;
import org.junit.Assert;
import org.junit.Test;

import java.awt.Color;
import java.util.ArrayList;


/**
 * To Represent my testing class.
 */
public class EasyAnimatorModelTest {

  EasyAnimatorOperations model1;
  EasyAnimatorOperations model2;
  AShape shape1;
  AShape shape2;
  AShape shape3;
  AAnimation move1;
  AAnimation move2;
  AAnimation move3;
  AAnimation move4;
  AAnimation changeColor1;
  AAnimation changeColor2;
  AAnimation changeColor3;
  AAnimation scale1;
  AAnimation scale2;
  AAnimation scale3;
  MyColor color1;
  MyColor color2;
  MyColor color3;
  Posn xy1;
  Posn xy2;
  Posn xy3;
  AAnimation scale4;
  IView v1;

  /**
   * Initial Conditions for tests.
   */
  void initConditions() {

    model1 = new EasyAnimatorModel();
    model2 = new EasyAnimatorModel();
    model1.startAnimator();
    color1 = new MyColor(0,0,0);
    color2 = new MyColor(100, 100, 100);
    color3 = new MyColor(100,100,100);
    xy1 = new Posn(1, 10);
    xy2 = new Posn(10, 10);
    xy3 = new Posn(10, 10);
    shape1 = new Rectangle("A", color2, 0, 100, 10, 20, xy1);
    shape2 = new Oval("B", color1, 0, 100, xy2, 50, 50);
    shape3 = new Oval("C", color1, 500, 600, xy2, 50, 50);
    move1 = new Move(shape1, 50, 100, xy2);
    move2 = new Move(shape2, 50, 100, xy1);
    move3 = new Move(shape2, 50, 100, xy1);
    move4 = new Move(shape2, 75, 150, xy1);
    changeColor1 = new ColorChange(shape1, 50, 100, color1);
    changeColor2 = new ColorChange(shape1, 50, 100, color1);
    changeColor3 = new ColorChange(shape2, 0, 50, color2);
    scale1 = new Scale(shape2, 0, 50, 50, 100);
    scale2 = new Scale(shape2, 0,50, 50, 100);
    scale3 = new Scale(shape1, 50, 100, 2, 3);
    v1 = new VisualView(1);

  }

  @Test
  public void testStartAnimation() {

    this.initConditions();
    Assert.assertEquals(true, model1.getAnimatorState().contains("Shapes:"));
    v1.render(model1);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testAnimationNotStarted() {

    this.initConditions();
    model2.getAnimatorState();

  }

  @Test
  public void testGetAnimationState() {

    this.initConditions();
    model1.addShape(shape1);
    model1.addShape(shape2);
    model1.addAnimation(scale1);
    model1.addAnimation(move1);
    model1.addAnimation(move2);
    v1.render(model1);

    Assert.assertEquals(true, model1.getAnimatorState().
            contains("Shape"));

  }

  @Test
  public void testAddAndRemoveShape() {

    this.initConditions();
    model1.addShape(shape1);
    Assert.assertEquals(true, model1.getAnimatorState().contains("Name: A"));
    model1.removeShape(shape1);
    Assert.assertEquals(true, !model1.getAnimatorState().contains("Name: A"));

  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveException() {

    this.initConditions();
    model1.removeShape(shape1);

  }

  @Test
  public void testAddAndRemoveAnimation() {

    this.initConditions();
    model1.addShape(shape1);
    model1.addAnimation(move1);
    Assert.assertEquals(true, model1.getAnimatorState().contains("moves from"));
    model1.removeAnimation(move1);
    Assert.assertEquals(false, model1.getAnimatorState().contains("moves from"));

  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddingIncompatibleAnimation() {

    this.initConditions();
    model1.addShape(shape1);
    model1.addShape(shape2);
    model1.addAnimation(scale1);
    model1.addAnimation(move1);
    model1.addAnimation(move2);
    model1.addAnimation(move4);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddAnimationWithoutAShape() {

    this.initConditions();
    model1.addAnimation(scale1);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testRemoveAnimationException() {

    this.initConditions();
    model1.addAnimation(move1);

  }

  @Test
  public void testEquals() {

    this.initConditions();
    Assert.assertEquals(true, shape1.equals(shape1));
    Assert.assertEquals(false, shape1.equals(shape2));
    Assert.assertEquals(true, move1.equals(move1));
    Assert.assertEquals(true, move2.equals(move3));
    Assert.assertEquals(false, move1.equals(move2));
    Assert.assertEquals(true, color2.equals(color3));
    Assert.assertEquals(false, color2.equals(move1));

  }

  @Test
  public void testPosnGetters() {

    this.initConditions();
    Assert.assertEquals(1, xy1.getX(),0);
    Assert.assertEquals(10, xy1.getY(),0);

  }

  @Test
  public void testMyColorToColor() {

    this.initConditions();
    Assert.assertEquals(new Color(0,0,0),color1.getColor());

  }

  @Test
  public void testAShapeGetters() {

    this.initConditions();
    Assert.assertEquals(shape1.getName(), "A");
    Assert.assertEquals(shape1.getColor(), color2);
    Assert.assertEquals(shape1.starts(),0);
    Assert.assertEquals(shape1.ends(), 100);

  }

  @Test
  public void testRectangleGetters() {

    this.initConditions();
    Assert.assertEquals(((Rectangle)shape1).getLLC(), xy1);
    Assert.assertEquals(((Rectangle)shape1).getWidth(), 10, 0);
    Assert.assertEquals(((Rectangle)shape1).getHeight(), 20,0);


  }

  @Test
  public void testOvalGetters() {

    this.initConditions();
    Assert.assertEquals(((Oval)shape2).getCenter(), xy2);
    Assert.assertEquals(((Oval)shape2).getxRadius(), 50, 0);
    Assert.assertEquals(((Oval)shape2).getyRadius(), 50, 0);

  }

  @Test
  public void testAAnimationGetters() {

    this.initConditions();
    Assert.assertEquals(move1.getAffected(), shape1);

  }

  @Test
  public void testValidAnim() {

    this.initConditions();
    ArrayList<AAnimation> arr = new ArrayList<>();
    arr.add(move1);
    arr.add(scale1);
    arr.add(move2);
    arr.add(changeColor1);
    Assert.assertEquals(true, changeColor3.validAnim(arr));
    Assert.assertEquals(false, changeColor2.validAnim(arr));

  }

  @Test
  public void testSameTime() {

    this.initConditions();
    Assert.assertEquals(false, ((ColorChange)changeColor2).sameTime(changeColor1));
    Assert.assertEquals(true, ((ColorChange)changeColor2).sameTime(changeColor3));
    Assert.assertEquals(true, ((Move)move1).sameTime(move2));
    Assert.assertEquals(false, ((Move)move3).sameTime(move4));
    Assert.assertEquals(false, ((Scale)scale1).sameTime(scale2));
    Assert.assertEquals(true, ((Scale)scale1).sameTime(scale3));

  }

  @Test(expected = IllegalArgumentException.class)
  public void testAnimationandShapeAtDifferentTimes() {

    this.initConditions();
    scale4 = new Scale(shape3, 0, 50, 1, 1);

  }

}
