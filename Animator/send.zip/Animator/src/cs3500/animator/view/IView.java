package cs3500.animator.view;

import cs3500.animator.model.AAnimation;
import cs3500.animator.model.AShape;
import cs3500.animator.model.EasyAnimatorOperations;

/**
 * Represents the view for the animator.
 * @param <T> The Return type for render.
 * @param <U> The Type of Shape used.
 * @param <V> The Type of Animation used.
 */
public interface IView<T, U, V>{
  /**
   * Renders the model according to the type T.
   * @param model model to be rendered
   * @return Something of type T.
   */
  T render(EasyAnimatorOperations<U, V> model);

  /**
   * Converts from ticks to seconds.
   * @param tick Ticks to be converted.
   * @return the seconds that were converted from ticks.
   */
  double convertTicks(int tick);
}
