package cs3500.animator.view;

import cs3500.animator.model.AAnimation;
import cs3500.animator.model.AShape;
import cs3500.animator.model.EasyAnimatorOperations;

public class SvgAnimationView implements IView<String, AShape, AAnimation> {

  private int tickRate;

  public SvgAnimationView(int tickRate) {

    this.tickRate = tickRate;

  }

  @Override
  public String render(EasyAnimatorOperations model) {
    return null;
  }

  @Override
  public double convertTicks(int tick) {
    return tick / this.tickRate;
  }
}
