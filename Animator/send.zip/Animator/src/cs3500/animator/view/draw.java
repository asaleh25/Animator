package cs3500.animator.view;

import cs3500.animator.model.AAnimation;
import cs3500.animator.model.AShape;
import cs3500.animator.model.EasyAnimatorOperations;

import javax.swing.*;
import java.awt.*;

public class draw extends JPanel {

    EasyAnimatorOperations<AShape, AAnimation> model;

    public draw(EasyAnimatorOperations model) {
        super();
        this.model = model;

    }

    public void drawing() {

        repaint();

    }

    public void paintComponent(Graphics g) {

        super.paintComponent(g);

        for (AShape a : this.model.getUpdatedShapes()) {

            a.updateDrawing(g);

        }


    }
}
