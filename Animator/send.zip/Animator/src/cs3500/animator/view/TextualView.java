package cs3500.animator.view;

import cs3500.animator.model.AAnimation;
import cs3500.animator.model.AShape;
import cs3500.animator.model.EasyAnimatorOperations;

public class TextualView implements IView<String, AShape, AAnimation> {

  private int tickRate;

  public TextualView(int tickRate) {
    this.tickRate = tickRate;
  }

  @Override
  public double convertTicks(int tick) {
    return tick / this.tickRate;
  }

  @Override
  public String render(EasyAnimatorOperations<AShape, AAnimation> model) {
      if (!model.animationStarted()) {

        throw new IllegalArgumentException("Animation hasn't started");

      }
      String shape = "Shapes: \n";
      for (AShape shap : model.getShapes()) {
        String temp = shap.toString();
        if (temp.contains("rectangle")) {
          temp = temp.replace("Lower-left corner", "Min-Corner");
        }
        temp = renderHelp(temp, true);
        shape = shape + temp + "\n\n";

      }

      for (AAnimation anim : model.getAnimations()) {

        String temp = anim.toString();
        temp = renderHelp(temp, false);
        shape = shape + temp + "\n";

      }

      return shape;
    }

    private String renderHelp(String s, boolean flag) {

      int appTick;
      int disTick;

      if (flag) {

          appTick = Integer.parseInt(s.substring(s.indexOf("=") + 1, s.indexOf("Disappears") - 1));
          disTick = Integer.parseInt(s.substring(s.lastIndexOf("=") + 1));

      } else {

          appTick = Integer.parseInt(s.substring(s.indexOf("=") + 1, s.lastIndexOf("t=") - 4));
          disTick = Integer.parseInt(s.substring(s.lastIndexOf("=") + 1));

      }

        double appTime = convertTicks(appTick);
        double disTime = convertTicks(disTick);
        String first = s.substring(0, s.indexOf("="));
        String second = s.substring(s.indexOf("="), s.lastIndexOf("="));
        String third = s.substring(s.lastIndexOf("="));
        second = second.replace(Integer.toString(appTick), Double.toString(appTime));
        third = third.replace(Integer.toString(disTick), Double.toString(disTime));
        return first + second + third;

    }
}
