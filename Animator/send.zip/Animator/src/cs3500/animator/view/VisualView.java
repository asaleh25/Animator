package cs3500.animator.view;

import cs3500.animator.model.AAnimation;
import cs3500.animator.model.AShape;
import cs3500.animator.model.EasyAnimatorOperations;
import javax.swing.*;
import java.awt.*;

public class VisualView extends JFrame implements IView<Void, AShape, AAnimation> {

    private int tickRate;

    public VisualView(int tickRate) {
        super("Animations");
        this.setSize(500, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
      this.tickRate = tickRate;

    }

    @Override
  public Void render(EasyAnimatorOperations model) {

        for (int t = 0; t <= model.getTotal(); t++) {

            draw o = new draw(model);
            this.add(o);
            o.drawing();
            model.onTick();

        }

        return null;

}
  @Override
  public double convertTicks(int tick) {
    return tick / this.tickRate;
  }
}
