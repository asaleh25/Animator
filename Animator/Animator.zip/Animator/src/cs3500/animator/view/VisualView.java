package cs3500.animator.view;

import cs3500.animator.model.AAnimation;
import cs3500.animator.model.AShape;
import cs3500.animator.model.EasyAnimatorOperations;

public class VisualView implements IView<Void, AShape, AAnimation> {

    private int tickRate;

    public VisualView(int tickRate) {

      this.tickRate = tickRate;

    }

    @Override
  public Void render(EasyAnimatorOperations model) {
    return null;
  }

  @Override
  public double convertTicks(int tick) {
    return tick / this.tickRate;
  }
}
