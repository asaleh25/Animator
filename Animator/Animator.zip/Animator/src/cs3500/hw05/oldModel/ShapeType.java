package cs3500.hw05.oldModel;

public enum ShapeType {
  CIRCLE, OVAL, SQUARE, RECTANGLE;
}
